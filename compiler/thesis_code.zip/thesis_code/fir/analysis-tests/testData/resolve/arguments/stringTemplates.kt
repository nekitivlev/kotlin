class A

fun foo(s: String) {}

fun test(a: A) {
    foo("$a")
}
