typealias Foo = Int

const val x: Foo = 10
