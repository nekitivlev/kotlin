// !DUMP_CFG
fun foo() {}

fun test() {
    val x = 1
    val y = x + 1
    foo()
}
