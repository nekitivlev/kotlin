// ISSUE: KT-53920

fun test() {
    return
    object {}
}
