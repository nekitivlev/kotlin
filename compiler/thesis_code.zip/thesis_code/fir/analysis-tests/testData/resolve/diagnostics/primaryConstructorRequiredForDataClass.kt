data <!DATA_CLASS_WITHOUT_PARAMETERS!>class A<!> {}

data <!DATA_CLASS_WITHOUT_PARAMETERS!>class B<!> {
    constructor()
}

data <!DATA_CLASS_WITHOUT_PARAMETERS!>class C<!> {
    constructor(x: Int)
}
