sealed class A

val b = <!INVISIBLE_REFERENCE!>A<!>()
