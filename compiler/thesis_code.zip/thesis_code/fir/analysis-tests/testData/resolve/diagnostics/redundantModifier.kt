<!REDUNDANT_MODIFIER!>open<!> abstract class A
<!REDUNDANT_MODIFIER!>abstract<!> sealed class B
