open class A


class B : A()
