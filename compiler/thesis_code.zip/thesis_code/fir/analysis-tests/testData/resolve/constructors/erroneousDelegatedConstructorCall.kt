// INFERENCE_HELPERS
class A : <!UNRESOLVED_REFERENCE!>Undefined<!>(id(materialize()))
