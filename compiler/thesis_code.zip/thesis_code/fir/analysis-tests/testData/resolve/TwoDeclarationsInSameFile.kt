package p


open class A

class B : A()
