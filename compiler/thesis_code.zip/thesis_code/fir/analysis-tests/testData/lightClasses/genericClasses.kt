interface A<T, V : CharSequence>

class B : A<Int, String>

// LIGHT_CLASS_FQ_NAME: A, B
