public abstract class AbstractMap implements java.util.Map<String, String> {

}